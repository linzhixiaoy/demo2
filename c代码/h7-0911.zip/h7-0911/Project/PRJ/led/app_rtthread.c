/*
 * File      : app_rtthread.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2012 - 2018, RT-Thread Development Team
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Change Logs:
 * Date           Author       Notes
 */
#include <spi.h>
#include <rtthread.h>
#include <app_rtthread.h>
//#include "teeny_usb.h"
//#include "TeenyUSB_it.h"
//#include "mailbox_app.h"

 struct rt_thread led1_thread;
ALIGN(4)  rt_uint8_t rt_led1_thread_stack[1024];
 struct rt_thread led2_thread;
ALIGN(4)  rt_uint8_t rt_led2_thread_stack[1024];
 struct rt_thread led3_thread;
ALIGN(4)  rt_uint8_t rt_led3_thread_stack[1024];


static char mb_str1[] = "I'm a mail!";
static char mb_str2[] = "I'm a mail!";
static struct rt_mailbox mb1;
static struct rt_mailbox mb2;
static char mb_pool[128];
uint8_t Tx[6] = {0x09,0x09,0x09,0x09,0x09,0x09};  // 0x8   0x05
uint8_t message1[5] = {0x01,0x01,0x01,0x01,0x01}; 
uint8_t message2[5] = {0x02,0x02,0x02,0x02,0x02}; 
uint8_t message3[5] = {0x03,0x03,0x03,0x03,0x03}; 
uint8_t message4[5] = {0x04,0x04,0x04,0x04,0x04}; 
uint8_t message5[5] = {0x05,0x05,0x05,0x05,0x05}; 
void MX_RT_Thread_Init(void)
{
  rt_thread_init(&led1_thread,        
                    "led1",             
                    led1_thread_entry, 
                    RT_NULL,            
                    &rt_led1_thread_stack[0],     
                    1024, 
                    3,                  
                    20); 
 	rt_thread_init(&led2_thread,        
                    "led2",             
                    led2_thread_entry, 
                    RT_NULL,            
                    &rt_led2_thread_stack[0],     
                    1024, 
                    3,                  
                    20);    
  rt_thread_init(&led3_thread,        
                    "led3",             
                    led3_thread_entry, 
                    RT_NULL,            
                    &rt_led3_thread_stack[0],     
                    1024, 
                    3,                  
                    20);     

rt_mb_init(&mb1,
					 "mbt", /* ������mbt */
					  &mb_pool[0], /* �����õ����ڴ����mb_pool */
						sizeof(mb_pool)/4, /* ��С��mb_pool/4����Ϊÿ���ʼ��Ĵ�С��4�ֽ� */
						RT_IPC_FLAG_FIFO);
rt_mb_init(&mb2,
					 "mbt", /* ������mbt */
					  &mb_pool[0], /* �����õ����ڴ����mb_pool */
						sizeof(mb_pool)/4, /* ��С��mb_pool/4����Ϊÿ���ʼ��Ĵ�С��4�ֽ� */
						RT_IPC_FLAG_FIFO);
}

void MX_RT_Thread_Process(void)
{
    rt_thread_startup(&led1_thread); 
		rt_thread_startup(&led2_thread);
//		rt_thread_startup(&led3_thread);
}


void led1_thread_entry(void* parameter)
	{
		int i=0,keys=0;		
    char *mb_msgr;
		rt_err_t res;
		while (1)
			{
//				SPI_Receive(&SPI2_Handler,&ReadS,1, 200);
				HAL_SPI_TransmitReceive(&SPI2_Handler,(uint8_t*)Tx_Buffer,(uint8_t*)ReadBuff,5, 100);
				if(ReadBuff[1]!=0){
				rt_mb_send(&mb1, (rt_uint32_t)&ReadBuff[1]);
				}
//				if(rt_mb_recv(&mb2, (rt_uint32_t*)&mb_msgr, RT_WAITING_FOREVER) == RT_EOK)
//        if(rt_mb_recv(mailbox1, (rt_uint32_t *)&mb_msg, RT_WAITING_FOREVER) == RT_EOK)
//       HAL_GPIO_TogglePin(GPIOA,GPIO_PIN_0|GPIO_PIN_1);
				rt_thread_delay(100); 
			}

	}
void led2_thread_entry(void* parameter)
	{
		 int i=0;
     char *mb_msgt;
			while (1)
			{
				if(rt_mb_recv(&mb1, (rt_uint32_t*)&mb_msgt, RT_WAITING_FOREVER) == RT_EOK)
				{
					if(*mb_msgt==1) {messagecopy(message1);}  
					if(*mb_msgt==2) {messagecopy(message2);}
					if(*mb_msgt==3) {messagecopy(message3);}
					if(*mb_msgt==4) {messagecopy(message4);}
					if(*mb_msgt==0) {messagecopy(message5);}  
				}
				rt_thread_delay(200);
			}
	}

void led3_thread_entry(void* parameter)
	{
		 int i=0;

			while (1)
			{
				if(usb_rx_data_cnt){
				for(int i=0;i<usb_rx_data_cnt;i++){
							usb_rx_buf[i]++;
						 }
						tusb_send_data(dev, TX_EP, usb_rx_buf, usb_rx_data_cnt, TUSB_TXF_ZLP);
						usb_rx_data_cnt = 0; 
					 }
				rt_thread_delay(50);
			}
			rt_thread_delay(50);
	}

void messagecopy(uint8_t* date)
{
	int i=0;
	for(i=0;i<=4;i++)
	{
		Tx_Buffer[i]=date[i];
	}

}
	
void messagequeue(uint8_t date)
{
//	    SPI_Receive(&SPI2_Handler,&ReadS,1, 200);
//	    if(date==8){rt_thread_suspend(&led1_thread);}
      if(ReadS==8){ReadS=0;HAL_SPI_TransmitReceive(&SPI2_Handler,(uint8_t*)SendBuff,(uint8_t*)ReadBuff,6, 200);}
			if(ReadS==6){ReadS=0;HAL_SPI_TransmitReceive(&SPI2_Handler,(uint8_t*)Tx_Buffer,(uint8_t*)ReadBuff,6, 200);message=0;}
			if(usb_rx_buf[0]==0x02){usb_rx_buf[0]=0;ReadS=0;rt_thread_resume(&led1_thread);message=1;} 
}




//    	SEND_DMA(&SPI2_Handler,(uint8_t *)Tx_Buffer,5);
//	     SendRead_DMA(&SPI2_Handler,(uint8_t *)Tx_Buffer,(uint8_t *)ReadBuff,5);
//	HAL_SPI_Transmit(&SPI2_Handler,(uint8_t*)Tx_Buffer,5, 200);

//			if(message==0)HAL_SPI_TransmitReceive(&SPI2_Handler,&SendS,&ReadS,1, 200);
//			HAL_SPI_TransmitReceive(&SPI2_Handler,(uint8_t*)SendBuff,(uint8_t*)ReadBuff,5, 200);
//			if(ReadBuff[1]!=0){*message=*ReadBuff;HAL_SPI_Transmit(&SPI2_Handler,(uint8_t*)Tx_Buffer,5, 200);}
//			if(*message==8){HAL_SPI_Transmit(&SPI2_Handler,(uint8_t*)Tx_Buffer,5, 200);ReadS=0;}
//			if(*message==6){HAL_SPI_Transmit(&SPI2_Handler,(uint8_t*)SendBuff,5, 200);ReadS=0;}