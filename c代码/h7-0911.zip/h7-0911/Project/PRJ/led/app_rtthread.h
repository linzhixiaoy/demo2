/*
 * File      : app_rtthread.h
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2012 - 2018, RT-Thread Development Team
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Change Logs:
 * Date           Author       Notes
 */

#include <rtthread.h>
#include "teeny_usb.h"
#include "TeenyUSB_it.h"
//#include <spi.h>



extern tusb_device_t* dev;
extern uint8_t SendBuff[200];  
extern uint8_t ReadBuff[10]; 
extern uint8_t SendS;  
extern uint8_t ReadS;
extern uint8_t message;
extern uint8_t Tx_Buffer[6];  // 0x8   0x05
extern DMA_HandleTypeDef DMA_Handle;


void MX_RT_Thread_Init(void);
void MX_RT_Thread_Process(void);

void led1_thread_entry(void* parameter);
void led2_thread_entry(void* parameter);
void led3_thread_entry(void* parameter);
void messagequeue(uint8_t date);
void messagecopy(uint8_t* date);



