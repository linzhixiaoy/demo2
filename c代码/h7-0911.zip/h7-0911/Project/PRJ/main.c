#include "main.h"
#include "LedBlink.h"
#include <app_rtthread.h>
#include "spi.h"
#include "teeny_usb.h"
#include "TeenyUSB_it.h"
#include "rtthread.h"

QSPI_HandleTypeDef hqspi;
uint8_t SendBuff[200];  
uint8_t ReadBuff[10]; 
uint8_t SendS=0;  
uint8_t ReadS=0;
uint8_t message;
tusb_device_t* dev;
uint8_t Tx_Buffer[6] = {0x01,0x02,0x3,0x4,0x05,0x06};  // 0x8   0x05


int main(void)
{  

  uint16_t i;	
	
	
  for(i=0;i<200;i++)
  {
    SendBuff[i]	 = 7;    
  }
  
	dev = tusb_get_device(TEST_APP_USB_CORE);
  tusb_open_device(dev);
	led_blink_thread_run();
//  MX_RT_Thread_Init();
//	MX_RT_Thread_Process();

	while (1)
	{

	}
}






void MX_QUADSPI_Init(void)
{
  hqspi.Instance = QUADSPI;
  hqspi.Init.ClockPrescaler = 255;
  hqspi.Init.FifoThreshold = 1;
  hqspi.Init.SampleShifting = QSPI_SAMPLE_SHIFTING_NONE;
  hqspi.Init.FlashSize = 1;
  hqspi.Init.ChipSelectHighTime = QSPI_CS_HIGH_TIME_1_CYCLE;
  hqspi.Init.ClockMode = QSPI_CLOCK_MODE_0;
  hqspi.Init.FlashID = QSPI_FLASH_ID_1;
  hqspi.Init.DualFlash = QSPI_DUALFLASH_DISABLE;
  if (HAL_QSPI_Init(&hqspi) != HAL_OK)
  {
    while(1);
  }
  /* USER CODE BEGIN QUADSPI_Init 2 */

  /* USER CODE END QUADSPI_Init 2 */

}



/****************************END OF FILE***************************/