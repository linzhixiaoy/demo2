#ifndef __MB_P4_H
#define __MB_P4_H
void MB_P4_Init(void);
void MB_P4_1ms_proc(void);

#endif 

//End
