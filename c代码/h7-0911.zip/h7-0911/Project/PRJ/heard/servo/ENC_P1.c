/**
  ******************************************************************************
  * @�ļ���    ENC_P1.c 
  * @����     
  * @�汾      V1.0.0
  * @����     
  * @����      Tamagawa encoder communication on USART1 
  ******************************************************************************
  * @ע������
  * �̶�������Ϊ 2500000��8,n,1
  *  
  * 
  ******************************************************************************
  */ 

#include "main.h"
//#include "ENC_P1.h"
#include "MBcrc.h"
#include "Globale_Variable.h"
//------------
#define ENC1_UART USART1 // Port1 usart1
#define ENC1_RX_STREAM 
#define ENC1_TX_STREAM
#define ENC1_RX_BUF USART1RXbuf
#define ENC1_TX_BUF USART1TXbuf
#define ENC1_RX_DMA DMA2_Stream2
#define ENC1_TX_DMA DMA2_Stream7
#define ENC1_RX_MAX 10
#define ENC1_TX_MAX 10
unsigned char USART1RXbuf[ENC1_RX_MAX];
unsigned char USART1TXbuf[ENC1_TX_MAX];
unsigned short USART1RXlen,USART1TXlen;
int p_ENC1_UART_state,ENC1_UART_state; //0:init 1:Sending 2:Wait respond 3:Done
int ENC1_state; // Encoder status 0: Read out EEPROM, 1:Read Encoder data, 2:Write EEPROM
int ENC1_addr;
unsigned char EEPROM_Write_Date;

//------------

void ENC_P1_Init(void) // ��ʼ��
{
  USART_InitTypeDef   USART_InitStructure; 	
  NVIC_InitTypeDef    NVIC_InitStructure;
	DMA_InitTypeDef     DMA_InitStructure;
	GPIO_InitTypeDef    GPIO_InitStructure;
  USART_ClockInitTypeDef USART_ClockInitStruct;//
	int i;

   /* DMA2 clock enable */
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2, ENABLE);
  /* Enable USART1, GPIOA, GPIOC and AFIO clocks */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD,ENABLE);
	
  /* Configure USART1 Tx (PA.9) as input floating */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOA, &GPIO_InitStructure); 
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_USART1); 
  
  /* Configure USART1 Rx (PA.10) as alternate function push-pull */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOA, &GPIO_InitStructure); 
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_USART1); 
	
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14; //GPIOD14
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;//????
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	//??100MHz
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP; //??????
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP; //??
	GPIO_Init(GPIOD,&GPIO_InitStructure); //???PG8

	DMA_DeInit(ENC1_RX_DMA);
  /* DMA2 Stream2 (triggered by USART1 Rx event) Config */
	DMA_InitStructure.DMA_Channel = DMA_Channel_4; 
  DMA_InitStructure.DMA_PeripheralBaseAddr = (u32)(&(USART1->DR));//
  DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)(&ENC1_RX_BUF);
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;
  DMA_InitStructure.DMA_BufferSize = ENC1_RX_MAX;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
  DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;
  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;    //     
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;//
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;//
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;//
  DMA_Init(ENC1_RX_DMA, &DMA_InitStructure); 
	DMA_Cmd(ENC1_RX_DMA, DISABLE);  //
	
	
	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);

  //---Configure USART1 -------------
  USART_DeInit(USART1);
	USART_InitStructure.USART_BaudRate=2500000;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
  USART_Init(USART1, &USART_InitStructure);
	USART_ClockStructInit(&USART_ClockInitStruct);//
	USART_ClockInit(USART1, &USART_ClockInitStruct);//
	
  /* Enable USART1 DMA RX request */
  USART_DMACmd(USART1, USART_DMAReq_Rx, ENABLE);
	// Interrupt configuration
  USART_ITConfig(USART1,USART_IT_TC,DISABLE);   //��������ж� DISABLE
  USART_ITConfig(USART1,USART_IT_IDLE,DISABLE);   //����IDLE�ж� DISABLE
	USART_ITConfig(USART1,USART_IT_RXNE,DISABLE);

  USART_ClearFlag(USART1, USART_FLAG_RXNE);//����жϱ�ʶ

	
 /* Enable the USART1 */
  USART_Cmd(USART1, ENABLE);	
	// UART ״̬��
	ENC1_UART_state=0; 
	for(i=0;i<10000;i++)// ��ʼ����Ҫʱ�䣬Ҫ�������ܹ����TC
	{
		USART_ClearFlag(USART1, USART_FLAG_TC);//����жϱ��
	}
	ENC1_state=0; //Initial for Readout EEPROM first
	ENC1_addr=0; //Read From 0
	
}

void DMA2_Stream7_IRQHandler(void) //UART1 ��������ж�
{
  if(DMA_GetITStatus(ENC1_TX_DMA,DMA_IT_TCIF7)==SET) // DMA2_Stream7 �������
	{
		DMA_ClearITPendingBit(ENC1_TX_DMA,DMA_IT_TCIF7);
		DMA_ClearFlag(ENC1_TX_DMA,DMA_IT_TCIF7);
		
// 		USART1->SR=~USART_FLAG_TC;  //�巢���жϱ�־
	
		USART_ITConfig(USART1,USART_IT_TC,ENABLE);  //�򿪴��ڷ����ж�
		ENC1_UART_state=1;
	}
}

//------------------------------------------------------

void USART1_IRQHandler(void)
{
	//DMA_InitTypeDef     DMA_InitStructure;
/*	
	if(((USART1->CR1)&0x40)&&((USART1->SR)&USART_FLAG_TC) )//��������ж� USARTx->SR
	{
		USART1->CR1&=~0X00000040;    // �ط����ж�
		USART1->SR=~USART_FLAG_TC;   //�巢��������
		USART1->SR=~USART_FLAG_IDLE; //�����߿��б�־ 
		USART1->CR1|=0X00000010;   //�����߿����ж�
//		DMA1_Stream1->NDTR = MBP3_RX_MAX;
//		DMA1_Stream1->CR|= (uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
		
		ENC1_UART_state=2;
		ENC1_TX_DISABLE;

		return;
	}
		
	if(((USART1->CR1)&0x20)&&((USART1->SR)&USART_FLAG_RXNE)!=0)   //���������ж�
	{
		USART1->CR1&=~0X00000020;    //�ؽ����ж�
		USART1->SR=~USART_FLAG_RXNE; //����ձ�־
		
		DMA1_Stream1->NDTR = ENC1_RX_MAX;
		DMA1_Stream1->CR|= (uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
		
		USART1->SR=~USART_FLAG_IDLE; //�����߿��б�־ 
		USART1->CR1|=0X00000010;   //�����߿����ж�
		ENC1_UART_state=1; 
		return;
	}
*/	
	if(((USART1->CR1)&0x10)&&((USART1->SR)&USART_FLAG_IDLE)!=0)  //���߿����ж�
	{
		
		USART1->SR=~USART_FLAG_IDLE; //����б�־
		do
		{
			USART1->SR;
			USART1->DR;
		}while(0);
		USART1RXlen=ENC1_RX_MAX-DMA2_Stream2->NDTR;
		
		DMA2_Stream2->CR&=~(uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
		DMA2_Stream2->NDTR = ENC1_RX_MAX;

		
		
		ENC1_UART_state=2; 
		
		return;
	}
	
	if(((USART1->SR)&USART_FLAG_ORE)!=0)//���Ǵ����ж�
	{
		USART1->CR1 &= (uint16_t)~((uint16_t)USART_CR1_UE);  //��USART1
		USART1->CR1 |= USART_CR1_UE;										//��USART1

		USART1->SR=~USART_IT_ORE;  //�帲�Ǵ����־
		
		DMA2_Stream2->CR&=~(uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
		DMA2_Stream2->NDTR = ENC1_RX_MAX;
		
		USART1->SR=~USART_FLAG_RXNE; //����ձ�־
		USART1->CR1|=0X00000010;    //�������ж�
		DMA2_Stream2->CR|= (uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
		
		return;
	}
	
	do
	{
		USART1->SR;
		USART1->DR;
	}while(0);
	
	// �����жϣ�����USART1
	
	USART_Cmd(USART1, DISABLE);
		
	DMA2_Stream2->CR&=~(uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
	DMA2_Stream2->NDTR = ENC1_RX_MAX;
	
	DMA_Cmd(DMA2_Stream2, DISABLE);//��������
	
	
	USART1->CR1|=0X00000020;    //�������ж�
	USART_Cmd(USART1, ENABLE);

}
unsigned int ENC_Send_cnt=0;
unsigned int ENC_Recv_cnt=0;
int ENC_ERR_count = 0;
int ENC_ERR_count1[5] = {0,0,0,0,0};
void ENC1_EEPROM_Recv(int addr) //EEPROM_READ ���ճ���
{
	if(USART1RXbuf[0]==0xEA && USART1RXbuf[1]==addr)
	{
		unsigned char crc8=USART1RXbuf[0]^USART1RXbuf[1]^USART1RXbuf[2];
		char *p=(char*)(&MBData[1024]);
		if(crc8==USART1RXbuf[3]) //CRC OK
		{
			p[addr]=USART1RXbuf[2];
		}
	}
}
int encchangecnt=0;
unsigned short penc;
void ENC1_Recv(void) //���ճ���
{
	if(USART1RXbuf[0]==0x02)
	{
		unsigned char crc8=USART1RXbuf[0]^USART1RXbuf[1]^USART1RXbuf[2]^USART1RXbuf[3]^USART1RXbuf[4];
		if(crc8==USART1RXbuf[5]) //CRC OK
		{
			penc=MBData[MB_ENC1_VALUE_OFFSET+1];
			
			unsigned int *p=(unsigned int*)&MBData[MB_ENC1_VALUE_OFFSET];
			MBData[MB_ENC1_VALUE_OFFSET]=*(unsigned short*)(&USART1RXbuf[2]);
			MBData[MB_ENC1_VALUE_OFFSET+1]=*(unsigned short*)(&USART1RXbuf[4]);
			MBData[MB_ENC1_VALUE_OFFSET+1]&=0x007F;
			*p=(*p)<<9;
			if(penc!=MBData[MB_ENC1_VALUE_OFFSET+1])
			{
				encchangecnt++;
			}
			MBData[MB_ENC1_STATUS_OFFSET]=USART1RXbuf[1];
			ENC_ERR_count = 0;
			USART1RXbuf[0]=0;
			if(ENC_Recv_cnt!=(ENC_Send_cnt-1))
			{
				MBData[MB_ENC1_STATUS_OFFSET]=USART1RXbuf[1]+0x100;
				ENC_ERR_count ++;
			}
			ENC_Recv_cnt=ENC_Send_cnt;
				
		}
		else
		{
			MBData[MB_ENC1_STATUS_OFFSET]=USART1RXbuf[1]+0x100;
			USART1RXbuf[0]=0;
			
			ENC_ERR_count++;;
			ENC_Recv_cnt=ENC_Send_cnt;
		}
	}
	else
	{
			MBData[MB_ENC1_STATUS_OFFSET]=USART1RXbuf[1]+0x100;
			USART1RXbuf[0]=0;
			ENC_ERR_count ++;
			ENC_Recv_cnt=ENC_Send_cnt;
	}
	
}
void ENC1_proc(void) //���ճ���
{
	extern long PreCodeSpeedLong;
	extern unsigned long PreCodeSpaceLong;
	extern unsigned long PreCodeSpaceLongOld;
	
	DMA_InitTypeDef     DMA_InitStructure;
	
	//-------------------------------------------------------------
	CodeSpaceLong	= *(unsigned long*)(&MBData[0]);
	CodeSpeedLong = CodeSpaceLong - CodeSpaceLongOld;
	CodeSpaceLongOld = CodeSpaceLong;
	
	//PreCodeSpaceLong = CodeSpaceLong + CodeSpeedLong;
	//PreCodeSpeedLong = PreCodeSpaceLong - PreCodeSpaceLongOld;
	//PreCodeSpaceLongOld = PreCodeSpaceLong;
	//-------------------------------------------------------------

	USART1->CR1|=(0X00000010);   //�����߿����ж�
	USART1->SR=~USART_FLAG_TC;   //�巢��������

	DMA_DeInit(ENC1_RX_DMA);
  /* DMA2 Stream2 (triggered by USART1 Rx event) Config */
	DMA_InitStructure.DMA_Channel = DMA_Channel_4; 
  DMA_InitStructure.DMA_PeripheralBaseAddr = (u32)(&(USART1->DR));//
  DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)(&ENC1_RX_BUF);
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;
  DMA_InitStructure.DMA_BufferSize = ENC1_RX_MAX;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
  DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;
  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;    //     
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;//
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;//
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;//
  DMA_Init(ENC1_RX_DMA, &DMA_InitStructure); 
	DMA_Cmd(ENC1_RX_DMA, ENABLE);  //
	
	DMA_ITConfig(ENC1_RX_DMA,DMA_IT_TC,ENABLE);//RX

//	USART1->CR1|=0X00000040;    //����������ж�
//	USART1->DR=0x2;
	ENC1_UART_state=1;	
}

void ENC1_EEPROM_Read()
{
		ENC1_TX_ENABLE;
		USART1->DR=0xEA;
		ENC1_proc();

}
//------------------------------------------------------
