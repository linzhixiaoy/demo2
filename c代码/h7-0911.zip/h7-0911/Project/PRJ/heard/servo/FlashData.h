#ifndef __FLASHDATA__H
#define __FLASHDATA__H

void ReadFlashPara(void);
void SaveFlashPara(void);
extern unsigned int SaveFlash ;
#endif 

//End
