#ifndef __MBCRC__H
#define __MBCRC__H
#include "stm32f4xx.h"

#define MB_MAX_REG 32768

extern void MB_CRC16(unsigned char* chkbuf,u16 len,unsigned char* uchCRCHi,unsigned char* uchCRCLo );
extern void MB_CRC16_BYWORD(u16 val,unsigned char* uchCRCHi,unsigned char* uchCRCLo );

extern void MB_LRC16(unsigned char* chkbuf,unsigned char len,unsigned char* uchLRC );
extern unsigned short RTU_Data_Proc(unsigned char *RXbuf,unsigned char *TXbuf,unsigned short RXlen,unsigned char ID);
extern unsigned short MBData[MB_MAX_REG];
#endif 

//End
