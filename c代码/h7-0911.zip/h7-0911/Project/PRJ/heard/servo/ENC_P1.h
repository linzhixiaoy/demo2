#ifndef __ENC_P1_H
#define __ENC_P1_H
void ENC_P1_Init(void);
void ENC1_proc(void);
void ENC1_Recv(void);
void ENC1_EEPROM_Recv(int addr);
extern int ENC1_state; // Encoder status 0: Read out EEPROM, 1:Read Encoder data, 2:Write EEPROM
extern int ENC1_addr;

#define ENC1_TX_ENABLE (GPIOD->ODR|=0x4000)
#define ENC1_TX_DISABLE (GPIOD->ODR&=(~0x4000))
#define MB_ENC1_VALUE_OFFSET 538
#define MB_ENC1_STATUS_OFFSET 540
#endif 

//End
