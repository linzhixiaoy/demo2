#ifndef __DBGMCUCONF__H
#define __DBGMCUCONF__H

void MCUDebugMode(void);

#endif 

//End
