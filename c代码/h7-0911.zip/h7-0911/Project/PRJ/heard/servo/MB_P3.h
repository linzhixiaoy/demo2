#ifndef __MB_P3_H
#define __MB_P3_H
void MB_P3_Init(void);
void MB_P3_1ms_proc(void);

#endif 

//End
