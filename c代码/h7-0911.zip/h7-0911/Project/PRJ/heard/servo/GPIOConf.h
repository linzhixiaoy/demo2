#ifndef __GPIOCONF_H
#define __GPIOCONF_H

void InitGPIO(void);

#endif 

//End
