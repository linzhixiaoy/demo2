#ifndef __ADC123CONF__H
#define __ADC123CONF__H
#include "main.h"

//void ADC123Conf(void); 
void  Adc_Init(void);
uint16_t Get_Adc(uint8_t ch);
uint16_t Get_Adc_Average(uint8_t ch,uint8_t times);
extern void GPIO_Set(GPIO_TypeDef* GPIOx,uint32_t BITx,uint32_t MODE,uint32_t OTYPE,uint32_t OSPEED,uint32_t PUPD);
extern int ADCValue[16];
#endif 

//End
