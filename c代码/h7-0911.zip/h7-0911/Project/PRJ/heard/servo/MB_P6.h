#ifndef __MB_P6_H
#define __MB_P6_H
void MB_P6_Init(void);
void MB_P6_1ms_proc(void);

#endif 

//End
