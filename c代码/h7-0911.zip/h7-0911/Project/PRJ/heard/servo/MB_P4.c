/**
  ******************************************************************************
  * @�ļ���    MB_P4.c 
  * @����     
  * @�汾      V1.0.0
  * @����     
  * @����      Modbus communication on USART4 
  ******************************************************************************
  * @ע������
  * �̶�������Ϊ 115200��8,n,1 RTU
  *  
  * 
  ******************************************************************************
  */ 

#include "main.h"
#include "MBcrc.h"
#include "MB_P4.h"
//------------
#define MBP4_UART UART4 // Port1 uart6 
#define MBP4_RX_MAX 256
#define MBP4_TX_MAX 256
unsigned char USART4RXbuf[MBP4_RX_MAX];
unsigned char USART4TXbuf[MBP4_TX_MAX];
unsigned short USART4RXlen,USART4TXlen;
int p_MBP4_UART_state,MBP4_UART_state; //0:�ȴ����յ�һ����; 1:�ȴ�IDLE 2:����ѶϢ�� 3:���ͣ�DMA�� 4:�ȴ����һ����TC

//------------

void MB_P4_Init(void) // ��ʼ��
{
  USART_InitTypeDef   USART_InitStructure; 	
  NVIC_InitTypeDef    NVIC_InitStructure;
	DMA_InitTypeDef     DMA_InitStructure;
	GPIO_InitTypeDef    GPIO_InitStructure;
  USART_ClockInitTypeDef USART_ClockInitStruct;//
	int i;

   /* DMA1 clock enable */
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1, ENABLE);
  /* Enable USART4, GPIOD, GPIOC and AFIO clocks */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC,ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD,ENABLE);
	
  /* Configure USART4 Tx (PC.10) as alternate function push-pull */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOC, &GPIO_InitStructure); 
	GPIO_PinAFConfig(GPIOC, GPIO_PinSource10, GPIO_AF_UART4); 

  /* Configure USART4 Rx (PC.11) as alternate function  */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOC, &GPIO_InitStructure); 
	GPIO_PinAFConfig(GPIOC, GPIO_PinSource11, GPIO_AF_UART4); 

  /* Configure USART4 RS485 Enable (PD.15) as general output  */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOD, &GPIO_InitStructure); 

	DMA_DeInit(DMA1_Stream2);
  /* DMA1 Stream2 (triggered by USART4 Rx event) Config */
	DMA_InitStructure.DMA_Channel = DMA_Channel_4; 
  DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)(&(UART4->DR));//
  DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)(&USART4RXbuf);
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;
  DMA_InitStructure.DMA_BufferSize = MBP4_RX_MAX;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
  DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;
  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Enable;    //     
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;//
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;//
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;//
  DMA_Init(DMA1_Stream2, &DMA_InitStructure); 
	DMA_Cmd(DMA1_Stream2, DISABLE);  //
	/* DMA1 Stream4 (triggered by USART4 Tx event) Config */
	DMA_DeInit(DMA1_Stream4);
	DMA_InitStructure.DMA_Channel = DMA_Channel_4; 
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)(&(UART4->DR));//
  DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)(&USART4TXbuf);
  DMA_InitStructure.DMA_DIR = DMA_DIR_MemoryToPeripheral;
	DMA_InitStructure.DMA_BufferSize = MBP4_TX_MAX;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
  DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;
  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Enable; //        
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;//
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;//
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;//
  DMA_Init(DMA1_Stream4, &DMA_InitStructure);
	DMA_Cmd(DMA1_Stream4, DISABLE);
	
	DMA_ITConfig(DMA1_Stream2,DMA_IT_TC,DISABLE);//RX
	DMA_ITConfig(DMA1_Stream4,DMA_IT_TC,ENABLE);//TX

	NVIC_InitStructure.NVIC_IRQChannel = DMA1_Stream4_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel = UART4_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);



  //---Configure USART4 -------------
  USART_DeInit(UART4);
	USART_InitStructure.USART_BaudRate=115200;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
  USART_Init(UART4, &USART_InitStructure);
	USART_ClockStructInit(&USART_ClockInitStruct);//
	USART_ClockInit(UART4, &USART_ClockInitStruct);//
	
  /* Enable USART1 DMA TX request */
  USART_DMACmd(UART4, USART_DMAReq_Tx, ENABLE);
  /* Enable USART1 DMA RX request */
  USART_DMACmd(UART4, USART_DMAReq_Rx, ENABLE);
	// Interrupt configuration
  USART_ITConfig(UART4,USART_IT_TC,DISABLE);   //��������ж� DISABLE
  USART_ITConfig(UART4,USART_IT_IDLE,DISABLE);   //����IDLE�ж� DISABLE
	USART_ITConfig(UART4,USART_IT_RXNE,ENABLE);

  USART_ClearFlag(UART4, USART_FLAG_RXNE);//����жϱ�ʶ

	GPIO_ResetBits(GPIOD,GPIO_Pin_15);
 /* Enable the USART6 */
  USART_Cmd(UART4, ENABLE);	
	// UART ״̬��
	MBP4_UART_state=0; 
	for(i=0;i<10000;i++)// ��ʼ����Ҫʱ�䣬Ҫ�������ܹ����TC
	{
		USART_ClearFlag(UART4, USART_FLAG_TC);//����жϱ��
	}	
}

void DMA1_Stream4_IRQHandler(void) //UART4 ��������ж�
{
  if(DMA_GetITStatus(DMA1_Stream4,DMA_IT_TCIF4)==SET) // DMA2_Stream6 �������
	{
		DMA_ClearITPendingBit(DMA1_Stream4,DMA_IT_TCIF4);
		DMA_ClearFlag(DMA1_Stream4,DMA_IT_TCIF4);
		
// 		USART6->SR=~USART_FLAG_TC;  //�巢���жϱ�־
	
		USART_ITConfig(UART4,USART_IT_TC,ENABLE);  //�򿪴��ڷ����ж�
		DMA1_Stream2->CR&=~(uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
		MBP4_UART_state=4; 
	}
}

//------------------------------------------------------

void UART4_IRQHandler(void)
{
	DMA_InitTypeDef     DMA_InitStructure;
		
	if(((UART4->CR1)&0x40)&&((UART4->SR)&USART_FLAG_TC) )//��������ж� USARTx->SR
	{
		UART4->CR1&=~0X00000040;    // �ط����ж�
		UART4->SR=~USART_FLAG_TC;   //�巢��������
		UART4->SR=~USART_FLAG_RXNE; //����ձ�־
		UART4->CR1|=0X00000020;    //�������ж�
				
		MBP4_UART_state=0; 
		//GPIO_ResetBits(GPIOD,GPIO_Pin_15);
		
		return;
	}
		
	if(((UART4->CR1)&0x20)&&((UART4->SR)&USART_FLAG_RXNE)!=0)   //���������ж�
	{
		UART4->CR1&=~0X00000020;    //�ؽ����ж�
		UART4->SR=~USART_FLAG_RXNE; //����ձ�־
		
		DMA1_Stream2->NDTR = MBP4_RX_MAX;
		DMA1_Stream2->CR|= (uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
		
		UART4->SR=~USART_FLAG_IDLE; //�����߿��б�־ 
		UART4->CR1|=0X00000010;   //�����߿����ж�
			//GPIO_ResetBits(GPIOD,GPIO_Pin_15);
		MBP4_UART_state=1; 
		return;
	}
		
	if(((UART4->CR1)&0x10)&&((UART4->SR)&USART_FLAG_IDLE)!=0)  //���߿����ж�
	{
		UART4->CR1&=~0X00000020;    //�ؽ����ж�
		UART4->SR=~USART_FLAG_RXNE; //����ձ�־
		
		UART4->CR1&=~0X00000010;    //�ؿ����ж�
		UART4->SR=~USART_FLAG_IDLE; //����б�־
		do
		{
			UART4->SR;
			UART4->DR;
		}while(0);
		USART4RXlen=MBP4_RX_MAX-DMA1_Stream2->NDTR;
		
		DMA1_Stream2->CR&=~(uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
		DMA1_Stream2->NDTR = MBP4_RX_MAX;
		//DMA1->LIFCR = DMA_Stream1_IT_MASK;
		DMA_DeInit(DMA1_Stream2);
		/* DMA1_Stream2 (triggered by USART4 Rx event) Config */
		DMA_InitStructure.DMA_Channel = DMA_Channel_4; 
		DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)(&(UART4->DR));//
		DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)(&USART4RXbuf);
		DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;
		DMA_InitStructure.DMA_BufferSize = MBP4_RX_MAX;
		DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
		DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
		DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
		DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
		DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
		DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;
		DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;    //     
		DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;//
		DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;//
		DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;//
		DMA_Init(DMA1_Stream2, &DMA_InitStructure); 
		DMA_Cmd(DMA1_Stream2, DISABLE);  //

		
		//	GPIO_ResetBits(GPIOD,GPIO_Pin_15);
		MBP4_UART_state=2; 
		
		return;
	}
	
	if(((UART4->SR)&USART_FLAG_ORE)!=0)//���Ǵ����ж�
	{
		UART4->CR1 &= (uint16_t)~((uint16_t)USART_CR1_UE);  //��USART1
		UART4->CR1 |= USART_CR1_UE;										//��USART1

		UART4->SR=~USART_IT_ORE;  //�帲�Ǵ����־
		
		DMA1_Stream2->CR&=~(uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
		DMA1_Stream2->NDTR = MBP4_RX_MAX;
		
		UART4->SR=~USART_FLAG_RXNE; //����ձ�־
		UART4->CR1|=0X00000020;    //�������ж�
		DMA1_Stream2->CR|= (uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
		MBP4_UART_state=0; 	
		//GPIO_ResetBits(GPIOD,GPIO_Pin_15);
		return;
	}
	
	do
	{
		UART4->SR;
		UART4->DR;
	}while(0);
	
	// �����жϣ�����USART6

	USART_Cmd(UART4, DISABLE);
		
	DMA1_Stream2->CR&=~(uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
	DMA1_Stream2->NDTR = MBP4_RX_MAX;
	
	DMA_Cmd(DMA1_Stream2, DISABLE);//��������
	
	UART4->SR=0;
	UART4->SR=~USART_FLAG_RXNE; //����ձ�־
	
	DMA1_Stream2->CR|= (uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
		
	MBP4_UART_state=0; 	
	//GPIO_ResetBits(GPIOD,GPIO_Pin_15);	
	UART4->CR1|=0X00000020;    //�������ж�
	USART_Cmd(UART4, ENABLE);

}
void MB_P4_1ms_proc(void) //��ֹ��������
{
	DMA_InitTypeDef     DMA_InitStructure;

	if(p_MBP4_UART_state==MBP4_UART_state) //״̬����
	{
		switch(MBP4_UART_state)
		{
			case 0: //�ȴ���һ����Ԫ
				if(!(UART4->SR&USART_FLAG_RXNE)) //�н��������ˣ�����Ƿ��ж�û��
				{
								
				}
				break;
			case 1: 
				break;
		}
	}
	if(MBP4_UART_state==2) // Data process
	{
		USART4TXlen=RTU_Data_Proc(USART4RXbuf,USART4TXbuf,USART4RXlen,2);
		if(USART4TXlen>0)
		{
			GPIO_SetBits(GPIOD,GPIO_Pin_15);
			DMA_DeInit(DMA1_Stream4);
			DMA_InitStructure.DMA_Channel = DMA_Channel_4; 
			DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)(&(UART4->DR));//
			DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)(&USART4TXbuf);
			DMA_InitStructure.DMA_DIR = DMA_DIR_MemoryToPeripheral;
			DMA_InitStructure.DMA_BufferSize = USART4TXlen;
			DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
			DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
			DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
			DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
			DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
			DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;
			DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Enable; //        
			DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;//
			DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;//
			DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;//
			DMA_Init(DMA1_Stream4, &DMA_InitStructure);
			DMA_Cmd(DMA1_Stream4, ENABLE);
			UART4->SR=~USART_FLAG_TC;   //�巢��������
			UART4->CR1|=0X00000040;    // �������ж�
			
			MBP4_UART_state=3;
		}
		else
		{			
			UART4->SR=~USART_FLAG_RXNE; //����ձ�־
			UART4->CR1|=0X00000020;    //�������ж�
			//GPIO_ResetBits(GPIOD,GPIO_Pin_15);
			
			MBP4_UART_state=0; 			
		}		
	}
	p_MBP4_UART_state=MBP4_UART_state;	
	
	if(MBP4_UART_state == 0)
		GPIO_ResetBits(GPIOD,GPIO_Pin_15);
}
//------------------------------------------------------
