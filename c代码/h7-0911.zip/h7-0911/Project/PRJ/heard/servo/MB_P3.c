/**
  ******************************************************************************
  * @�ļ���    MB_P3.c 
  * @����     
  * @�汾      V1.0.0
  * @����     
  * @����      Modbus communication on USART3 
  ******************************************************************************
  * @ע������
  * �̶�������Ϊ 115200��8,n,1 RTU
  *  
  * 
  ******************************************************************************
  */ 

#include "main.h"
#include "MBcrc.h"
#include "MB_P3.h"
//------------
#define MBP3_UART UART3 // Port1 uart3 
#define MBP3_RX_MAX 256
#define MBP3_TX_MAX 256
unsigned char USART3RXbuf[MBP3_RX_MAX];
unsigned char USART3TXbuf[MBP3_TX_MAX];
unsigned short USART3RXlen,USART3TXlen;
int p_MBP3_UART_state,MBP3_UART_state; //0:�ȴ����յ�һ����; 1:�ȴ�IDLE 2:����ѶϢ�� 3:���ͣ�DMA�� 4:�ȴ����һ����TC

//------------

void MB_P3_Init(void) // ��ʼ��
{
  USART_InitTypeDef   USART_InitStructure; 	
  NVIC_InitTypeDef    NVIC_InitStructure;
	DMA_InitTypeDef     DMA_InitStructure;
	GPIO_InitTypeDef    GPIO_InitStructure;
  USART_ClockInitTypeDef USART_ClockInitStruct;//
	int i;

   /* DMA1 clock enable */
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1, ENABLE);
  /* Enable USART3, GPIOB, GPIOC and AFIO clocks */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);
	
  /* Configure USART3 Tx (PB.10) as alternate function push-pull */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOB, &GPIO_InitStructure); 
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource10, GPIO_AF_USART3); 

  /* Configure USART3 Rx (PB.11) as alternate function  */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOB, &GPIO_InitStructure); 
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource11, GPIO_AF_USART3); 

	DMA_DeInit(DMA1_Stream1);
  /* DMA1 Stream1 (triggered by USART3 Rx event) Config */
	DMA_InitStructure.DMA_Channel = DMA_Channel_4; 
  DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)(&(USART3->DR));//
  DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)(&USART3RXbuf);
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;
  DMA_InitStructure.DMA_BufferSize = MBP3_RX_MAX;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
  DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;
  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;    //     
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;//
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;//
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;//
  DMA_Init(DMA1_Stream1, &DMA_InitStructure); 
	DMA_Cmd(DMA1_Stream1, DISABLE);  //
	/* DMA1 Stream3 (triggered by USART3 Tx event) Config */
	DMA_DeInit(DMA1_Stream3);
	DMA_InitStructure.DMA_Channel = DMA_Channel_4; 
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)(&(USART3->DR));//
  DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)(&USART3TXbuf);
  DMA_InitStructure.DMA_DIR = DMA_DIR_MemoryToPeripheral;
	DMA_InitStructure.DMA_BufferSize = MBP3_TX_MAX;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
  DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;
  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable; //        
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;//
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;//
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;//
  DMA_Init(DMA1_Stream3, &DMA_InitStructure);
	DMA_Cmd(DMA1_Stream3, DISABLE);
	
	DMA_ITConfig(DMA1_Stream1,DMA_IT_TC,DISABLE);//RX
	DMA_ITConfig(DMA1_Stream3,DMA_IT_TC,ENABLE);//TX

	NVIC_InitStructure.NVIC_IRQChannel = DMA1_Stream3_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);



  //---Configure USART3 -------------
  USART_DeInit(USART3);
	USART_InitStructure.USART_BaudRate=115200;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
  USART_Init(USART3, &USART_InitStructure);
	USART_ClockStructInit(&USART_ClockInitStruct);//
	USART_ClockInit(USART3, &USART_ClockInitStruct);//
	
  /* Enable USART1 DMA TX request */
  USART_DMACmd(USART3, USART_DMAReq_Tx, ENABLE);
  /* Enable USART1 DMA RX request */
  USART_DMACmd(USART3, USART_DMAReq_Rx, ENABLE);
	// Interrupt configuration
  USART_ITConfig(USART3,USART_IT_TC,DISABLE);   //��������ж� DISABLE
  USART_ITConfig(USART3,USART_IT_IDLE,DISABLE);   //����IDLE�ж� DISABLE
	USART_ITConfig(USART3,USART_IT_RXNE,ENABLE);

  USART_ClearFlag(USART3, USART_FLAG_RXNE);//����жϱ�ʶ

	
 /* Enable the USART3 */
  USART_Cmd(USART3, ENABLE);	
	// UART ״̬�� : 
	//0 wait for rx,
	//1 received first byte,waiting for idle
	//2 received packet done, wait main program to process
	//3 Process done, initial TX
	//4 DMA trasmission done, waiting for last byte to transmit
	//
	MBP3_UART_state=0; 
	for(i=0;i<10000;i++)// ��ʼ����Ҫʱ�䣬Ҫ�������ܹ����TC
	{
		USART_ClearFlag(USART3, USART_FLAG_TC);//����жϱ��
	}
	
}

void DMA1_Stream3_IRQHandler(void) //UART3 ��������ж�
{
  if(DMA_GetITStatus(DMA1_Stream3,DMA_IT_TCIF3)==SET) // DMA1_Stream3 �������
	{
		DMA_ClearITPendingBit(DMA1_Stream3,DMA_IT_TCIF3);
		DMA_ClearFlag(DMA1_Stream3,DMA_IT_TCIF3);
		
// 		USART3->SR=~USART_FLAG_TC;  //�巢���жϱ�־
	
		USART_ITConfig(USART3,USART_IT_TC,ENABLE);  //�򿪴��ڷ����ж�
		DMA1_Stream1->CR&=~(uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
		MBP3_UART_state=4; 
	}
}

//------------------------------------------------------

void USART3_IRQHandler(void)
{
	DMA_InitTypeDef     DMA_InitStructure;
		
	if(((USART3->CR1)&0x40)&&((USART3->SR)&USART_FLAG_TC) )//��������ж� USARTx->SR
	{
		USART3->CR1&=~0X00000040;    // �ط����ж�
		USART3->SR=~USART_FLAG_TC;   //�巢��������
		USART3->SR=~USART_FLAG_RXNE; //����ձ�־
		USART3->CR1|=0X00000020;    //�������ж�
//		DMA1_Stream1->NDTR = MBP3_RX_MAX;
//		DMA1_Stream1->CR|= (uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
	/* DMA1 Stream3 (triggered by USART3 Tx event) Config */
		
		
		
		MBP3_UART_state=0; 

		return;
	}
		
	if(((USART3->CR1)&0x20)&&((USART3->SR)&USART_FLAG_RXNE)!=0)   //���������ж�
	{
		USART3->CR1&=~0X00000020;    //�ؽ����ж�
		USART3->SR=~USART_FLAG_RXNE; //����ձ�־
		
		DMA1_Stream1->NDTR = MBP3_RX_MAX;
		DMA1_Stream1->CR|= (uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
		
		USART3->SR=~USART_FLAG_IDLE; //�����߿��б�־ 
		USART3->CR1|=0X00000010;   //�����߿����ж�
		MBP3_UART_state=1; 
		return;
	}
		
	if(((USART3->CR1)&0x10)&&((USART3->SR)&USART_FLAG_IDLE)!=0)  //���߿����ж�
	{
		USART3->CR1&=~0X00000020;    //�ؽ����ж�
		USART3->SR=~USART_FLAG_RXNE; //����ձ�־
		
		USART3->CR1&=~0X00000010;    //�ؿ����ж�
		USART3->SR=~USART_FLAG_IDLE; //����б�־
		do
		{
			USART3->SR;
			USART3->DR;
		}while(0);
		USART3RXlen=MBP3_RX_MAX-DMA1_Stream1->NDTR;
		
		DMA1_Stream1->CR&=~(uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
		DMA1_Stream1->NDTR = MBP3_RX_MAX;
		//DMA1->LIFCR = DMA_Stream1_IT_MASK;
		DMA_DeInit(DMA1_Stream1);
		/* DMA1 Stream1 (triggered by USART3 Rx event) Config */
		DMA_InitStructure.DMA_Channel = DMA_Channel_4; 
		DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)(&(USART3->DR));//
		DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)(&USART3RXbuf);
		DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;
		DMA_InitStructure.DMA_BufferSize = MBP3_RX_MAX;
		DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
		DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
		DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
		DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
		DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
		DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;
		DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;    //     
		DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;//
		DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;//
		DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;//
		DMA_Init(DMA1_Stream1, &DMA_InitStructure); 
		DMA_Cmd(DMA1_Stream1, DISABLE);  //

		
		
		MBP3_UART_state=2; 
		
		return;
	}
	
	if(((USART3->SR)&USART_FLAG_ORE)!=0)//���Ǵ����ж�
	{
		USART3->CR1 &= (uint16_t)~((uint16_t)USART_CR1_UE);  //��USART1
		USART3->CR1 |= USART_CR1_UE;										//��USART1

		USART3->SR=~USART_IT_ORE;  //�帲�Ǵ����־
		
		DMA1_Stream1->CR&=~(uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
		DMA1_Stream1->NDTR = MBP3_RX_MAX;
		
		USART3->SR=~USART_FLAG_RXNE; //����ձ�־
		USART3->CR1|=0X00000020;    //�������ж�
		DMA1_Stream1->CR|= (uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
		
		return;
	}
	
	do
	{
		USART3->SR;
		USART3->DR;
	}while(0);
	
	// �����жϣ�����USART3
	
	USART_Cmd(USART3, DISABLE);
		
	DMA1_Stream1->CR&=~(uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
	DMA1_Stream1->NDTR = MBP3_RX_MAX;
	
	DMA_Cmd(DMA1_Stream1, DISABLE);//��������
	
	USART3->SR=0;
	USART3->SR=~USART_FLAG_RXNE; //����ձ�־
	
	DMA1_Stream1->CR|= (uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
		
	
	USART3->CR1|=0X00000020;    //�������ж�
	USART_Cmd(USART3, ENABLE);

}
void MB_P3_1ms_proc(void) //��ֹ��������
{
	DMA_InitTypeDef     DMA_InitStructure;

	if(p_MBP3_UART_state==MBP3_UART_state) //״̬����
	{
		switch(MBP3_UART_state)
		{
			case 0: //�ȴ���һ����Ԫ
				if(!(USART3->SR&USART_FLAG_RXNE)) //�н��������ˣ�����Ƿ��ж�û��
				{
								
				}
				break;
			case 1: 
				break;
		}
	}
	if(MBP3_UART_state==2) // Data process
	{
		USART3TXlen=RTU_Data_Proc(USART3RXbuf,USART3TXbuf,USART3RXlen,2);
		if(USART3TXlen>0)
		{
			
	DMA_DeInit(DMA1_Stream3);
	DMA_InitStructure.DMA_Channel = DMA_Channel_4; 
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)(&(USART3->DR));//
  DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)(&USART3TXbuf);
  DMA_InitStructure.DMA_DIR = DMA_DIR_MemoryToPeripheral;
	DMA_InitStructure.DMA_BufferSize = USART3TXlen;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
  DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;
  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable; //        
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;//
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;//
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;//
  DMA_Init(DMA1_Stream3, &DMA_InitStructure);
	DMA_Cmd(DMA1_Stream3, ENABLE);
		USART3->SR=~USART_FLAG_TC;   //�巢��������
		USART3->CR1|=0X00000040;    // �������ж�
			
			MBP3_UART_state=3;
		}
		else
		{
			USART3->SR=~USART_FLAG_RXNE; //����ձ�־
			USART3->CR1|=0X00000020;    //�������ж�
			MBP3_UART_state=0; 
			
		}
		
	}
	p_MBP3_UART_state=MBP3_UART_state;	
}


//------------------------------------------------------
