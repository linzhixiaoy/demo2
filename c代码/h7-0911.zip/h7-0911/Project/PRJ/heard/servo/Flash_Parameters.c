#include "Flash_Parameters.h"
#include "MBcrc.h"
u8 *Flash_Para=(u8*)(0x08060000);

u8 sector_state[MAX_SECTOR];
u8 sector_to_write,sector_to_read;
void check_flash_para()
{
	sector_to_read=MAX_SECTOR;
	sector_to_write=MAX_SECTOR;
	for(int i=0;i<MAX_SECTOR;i++)
	{
		sector_state[i]=check_empty_sector(i);
		if(sector_state[i]==1) // Non empty
		{
			sector_state[i]=check_sector_crc(i);
			if(sector_state[i]==2)
				sector_to_read=i;
		}
	}
	for(int i=0;i<MAX_SECTOR;i++)
	{
		if(sector_state[i]==0) // Empty
		{
			sector_to_write=i;
			break;
		}
	}
	if(sector_to_read==MAX_SECTOR) // No valid entry to read
	{
		FLASH_Unlock();
		FLASH_EraseSector(FLASH_Sector_7, VoltageRange_3); //Erase sector 7
		Set_to_default(); //Set device to default
		for(int i=0;i<MAX_SECTOR;i++)
		{
			sector_state[i]=check_empty_sector(i);
			if(sector_state[i]==1) // Non empty
			{
				sector_state[i]=check_sector_crc(i);
				if(sector_state[i]==2)
					sector_to_read=i;
			}
		}
		Write_Para(sector_to_write);
		FLASH_Lock();
		for(int i=sector_to_write+1;i<MAX_SECTOR;i++)
		{
			if(sector_state[i]==0) //empty sector
			{
				sector_to_write=i;
				break;
			}
		}
	}
	else
	{
		Read_Para(sector_to_read);
		if(sector_to_write==MAX_SECTOR) //No empty sector to write, erase and write one sector first
		{
			FLASH_Unlock();
			FLASH_EraseSector(FLASH_Sector_7, VoltageRange_3); //Erase sector 7
			FLASH_Lock();

			for(int i=0;i<MAX_SECTOR;i++)
			{
				sector_state[i]=check_empty_sector(i);
				if(sector_state[i]==1) // Non empty
				{
					sector_state[i]=check_sector_crc(i);
					if(sector_state[i]==2)
						sector_to_read=i;
				}
				else
				{
					sector_to_write=i;
				}
			}
			Write_Para(sector_to_write);
			for(int i=sector_to_write+1;i<MAX_SECTOR;i++)
			{
				if(sector_state[i]==0) //empty sector
				{
					sector_to_write=i;
					break;
				}
			}
		}
	}

}
void Read_Para(u16 sector)
{
	u16 *p=(u16*)&Flash_Para[SECTOR_SIZE*sector];
	if(sector<MAX_SECTOR)
	{
		for(int i=0;i<SECTOR_SIZE/2;i++)
		{
			MBData[i]=p[i];
		}
	}
}	
void Write_Config()
{
	Write_Para(sector_to_write);
	for(int i=sector_to_write+1;i<MAX_SECTOR;i++)
	{
			if(sector_state[i]==0) //empty sector
			{
				sector_to_write=i;
				break;
			}
	}
}	
void Write_Para(u16 sector)
{
	FLASH_Unlock();

	u16 *p=(u16*)&Flash_Para[SECTOR_SIZE*sector];
	if(sector<MAX_SECTOR)
	{
		u8 crchi,crclo;
		u16 val;
		int i;
		crchi=0xff;
		crclo=0xff;
		for(i=0;i<SECTOR_SIZE/2-1;i++)
		{
			val=MBData[i];
			FLASH_ProgramHalfWord((uint32_t)(&p[i]), val);
			MB_CRC16_BYWORD(val,&crchi,&crclo);
		}
		val=(((u16)crchi)<<8)+((u16)crclo);
		MBData[i]=val;
		FLASH_ProgramHalfWord((uint32_t)(&p[i]), val);
	}
	FLASH_Lock();

}
u8 check_empty_sector(u16 sector)
{
	u32 *p=(u32*)&Flash_Para[SECTOR_SIZE*sector];
	if(sector<MAX_SECTOR)
	{
		for(int i=0;i<SECTOR_SIZE/4;i++)
			if(p[i]!=0xFFFFFFFF)
				return 1;
		return 0;	
	}
	else
	{
		return 0;
	}
}
u8 check_sector_crc(u16 sector)
{
	u8 *p=&Flash_Para[SECTOR_SIZE*sector];
	if(sector<MAX_SECTOR)
	{
		u8 crchi,crclo;
		MB_CRC16(p,SECTOR_SIZE-2,&crchi,&crclo );
		if(p[SECTOR_SIZE-2]==crclo && p[SECTOR_SIZE-1]==crchi)
			return 2;
		else
			return 1;
	}
	else
	{
		return 0;
	}
}
