/**
  ******************************************************************************
  * @�ļ���    MBcrc.c 
  * @����     
  * @�汾      V1.0.0
  * @����     
  * @����      Modbus CRC����
  ******************************************************************************
  * @ע������
  * 
  *  
  * 
  ******************************************************************************
  */ 
#include "MBcrc.h"
#include "LED_UI.h"
#include <stdio.h>
#include "Enable.h"

#define SV_ON EN_s.EN

unsigned short MBData[MB_MAX_REG];

unsigned char const auchCRCHi_exp[]={
0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,0x01,0xc0,0x80,0x41,0x00,0xc1,0x81,0x40,	
0x01,0xc0,0x80,0x41,0x00,0xc1,0x81,0x40,0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,
0x01,0xc0,0x80,0x41,0x00,0xc1,0x81,0x40,0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,
0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,0x01,0xc0,0x80,0x41,
0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,0x00,0xc1,0x81,0x40,0x00,0xc1,0x81,0x40,
0x01,0xc0,0x80,0x41,0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,0x01,0xc0,0x80,0x41,
0x00,0xc1,0x81,0x40,0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,0x01,0xc0,0x80,0x41,		
0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,0x00,0xc1,0x81,0x40,
0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,0x01,0xc0,0x80,0x41,0x00,0xc1,0x81,0x40,
0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,
0x01,0xc0,0x80,0x41,0x00,0xc1,0x81,0x40,0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,
0x01,0xc0,0x80,0x41,0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,
0x00,0xc1,0x81,0x40,0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,0x00,0xc1,0x81,0x40,
0x01,0xc0,0x80,0x41,0x01,0xc0,0x80,0x41,0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,
0x00,0xc1,0x81,0x40,0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,0x01,0xc0,0x80,0x41,
0x00,0xc1,0x81,0x40,0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,
0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,0x01,0xc0,0x80,0x41,0x00,0xc1,0x81,0x40,
};
unsigned char const auchCRCLo_exp[]={
0x00,0xc0,0xc1,0x01,0xc3,0x03,0x02,0xc2,0xc6,0x06,0x07,0xc7,0x05,0xc5,0xc4,0x04,
0xcc,0x0c,0x0d,0xcd,0x0f,0xcf,0xce,0x0e,0x0a,0xca,0xcb,0x0b,0xc9,0x09,0x08,0xc8,
0xd8,0x18,0x19,0xd9,0x1b,0xdb,0xda,0x1a,0x1e,0xde,0xdf,0x1f,0xdd,0x1d,0x1c,0xdc,
0x14,0xd4,0xd5,0x15,0xd7,0x17,0x16,0xd6,0xd2,0x12,0x13,0xd3,
0x11,0xd1,0xd0,0x10,0xf0,0x30,0x31,0xf1,0x33,0xf3,0xf2,0x32,0x36,0xf6,0xf7,0x37,
0xf5,0x35,0x34,0xf4,0x3c,0xfc,0xfd,0x3d,0xff,0x3f,0x3e,0xfe,0xfa,0x3a,0x3b,0xfb,
0x39,0xf9,0xf8,0x38,0x28,0xe8,0xe9,0x29,0xeb,0x2b,0x2a,0xea,0xee,0x2e,0x2f,0xef,
0x2d,0xed,0xec,0x2c,0xe4,0x24,0x25,0xe5,0x27,0xe7,0xe6,0x26,
0x22,0xe2,0xe3,0x23,0xe1,0x21,0x20,0xe0,0xa0,0x60,0x61,0xa1,0x63,0xa3,0xa2,0x62,
0x66,0xa6,0xa7,0x67,0xa5,0x65,0x64,0xa4,0x6c,0xac,0xad,0x6d,0xaf,0x6f,0x6e,0xae,
0xaa,0x6a,0x6b,0xab,0x69,0xa9,0xa8,0x68,0x78,0xb8,0xb9,0x79,0xbb,0x7b,0x7a,0xba,
0xbe,0x7e,0x7f,0xbf,0x7d,0xbd,0xbc,0x7c,0xb4,0x74,0x75,0xb5,
0x77,0xb7,0xb6,0x76,0x72,0xb2,0xb3,0x73,0xb1,0x71,0x70,0xb0,0x50,0x90,0x91,0x51,
0x93,0x53,0x52,0x92,0x96,0x56,0x57,0x97,0x55,0x95,0x94,0x54,0x9c,0x5c,0x5d,0x9d,
0x5f,0x9f,0x9e,0x5e,0x5a,0x9a,0x9b,0x5b,0x99,0x59,0x58,0x98,0x88,0x48,0x49,0x89,
0x4b,0x8b,0x8a,0x4a,0x4e,0x8e,0x8f,0x4f,0x8d,0x4d,0x4c,0x8c,
0x44,0x84,0x85,0x45,0x87,0x47,0x46,0x86,0x82,0x42,0x43,0x83,0x41,0x81,0x80,0x40
};

void MB_CRC16_BYWORD(u16 val,unsigned char* uchCRCHi,unsigned char* uchCRCLo )
{
	unsigned char uIndex;	
	uIndex= (*uchCRCHi)^((u8)(val&0xff));
	*uchCRCHi=*uchCRCLo^auchCRCHi_exp[uIndex];
	*uchCRCLo=auchCRCLo_exp[uIndex];		
	uIndex= (*uchCRCHi)^((u8)((val&0xff00)>>8));
	*uchCRCHi=*uchCRCLo^auchCRCHi_exp[uIndex];
	*uchCRCLo=auchCRCLo_exp[uIndex];		
}
void MB_CRC16(unsigned char* chkbuf,u16 len,unsigned char* uchCRCHi,unsigned char* uchCRCLo )
{
	unsigned char uIndex;	
	unsigned char crc_hi,crc_lo;	
	crc_hi=0xff;
	crc_lo=0xff;
	while(len--)
	{
		uIndex= (crc_hi)^*chkbuf++;
		crc_hi=crc_lo^auchCRCHi_exp[uIndex];
		crc_lo=auchCRCLo_exp[uIndex];		
	}
	*uchCRCHi=crc_hi;
	*uchCRCLo=crc_lo;
	
	//chk_sum=uchCRCHi;
	//chk_sum=((unsigned short)chk_sum<<8)|(uchCRCLo&0xff);	
	//return chk_sum;	
}


void MB_LRC16(unsigned char* chkbuf,unsigned char len,unsigned char* uchLRC )
{
	unsigned short uIndex;	
	
	uIndex=0;
	while(len--)
	{
		uIndex= uIndex+*chkbuf++;
	}
	uIndex=0x100-(uIndex&0x00ff);
	* uchLRC=(unsigned char)uIndex;
}

unsigned short RTU_Data_Proc(unsigned char *RXbuf,unsigned char *TXbuf,unsigned short RXlen,unsigned char ID)
{
	unsigned char crcH,crcL;
	unsigned short startadr,reg_num,TXlen,value;
	unsigned char *TXpt;
	u32 writeok;
	int i;

	if(RXbuf[0]==ID) //Station Number OK
	{
		MB_CRC16(RXbuf,RXlen-2,&crcH,&crcL);
		if( RXbuf[RXlen-1]==crcL && RXbuf[RXlen-2]==crcH) // CRC check OK
		{
			switch(RXbuf[1]) //Function number
			{
				case 3:// Read Register
					if((RXbuf[4]!=0)|| (RXbuf[5]>125)||(RXlen!=8)) // Register number >125 or packet length is not correct(8)
					{
						return 0;
					}
					startadr=(RXbuf[2]<<8)+RXbuf[3];
				  reg_num=(RXbuf[5]);
					if((startadr+reg_num)>=MB_MAX_REG) //Outbound
					{
						return 0;
					}
					TXbuf[0]=RXbuf[0];TXbuf[1]=RXbuf[1];
					TXbuf[2]=(unsigned char)(reg_num<<1);
					TXpt=&TXbuf[3];
					TXlen=TXbuf[2]+5;
					for(i=0;i<reg_num;i++)
					{
						unsigned short tmp=MBData[startadr+i];
						*TXpt=tmp>>8;
						TXpt++;
						*TXpt=tmp&0xff;
						TXpt++;
					}
					MB_CRC16(TXbuf,TXlen-2,&TXbuf[TXlen-2],&TXbuf[TXlen-1]);
					return TXlen;
					//break;
				case 6:// Write single Register
					writeok=0;
					if((RXlen!=8)) //  packet length is not correct(8)
					{
						return 0;
					}
					startadr=(RXbuf[2]<<8)+RXbuf[3];
					value=(RXbuf[4]<<8)+RXbuf[5];
					if((startadr)>=MB_MAX_REG) //Outbound
					{
						return 0;
					}
					else
					{
						int index=0;
						// Check if address in the parameter list
						while(index<MAX_MBDEF)
						{
							u16 _type=Modbus_def[index].type;
							u16 _offset= Modbus_def[index].offset;
							u32 *p=(u32*)&MBData[_offset];
							u32 v;
							if(_type== MBDEF_U32 ) //32 bit address
							{
								if(startadr==_offset)
								{
									v=((*p)&0xffff0000)+value;
									if(Modbus_def[index].check!= NULL)
									{
										if((!SV_ON) ||(SV_ON &&(Modbus_def[index].write_mode==MBDEF_Enable_SON) ))
										{
											if(Modbus_def[index].check(Modbus_def[index].min,Modbus_def[index].max,v)) //Check OK
											{
												(*p)=v;
												writeok=1;
												if(Modbus_def[index].execute!= NULL)
												{
													Modbus_def[index].execute();
												}
											}
										}
									}
									break;
								}
								if(startadr==_offset+1)
								{
									v=((*p)&0x0000ffff)+((u32)value<<16);
									if(Modbus_def[index].check!= NULL)
									{
										if((!SV_ON) ||(SV_ON &&(Modbus_def[index].write_mode==MBDEF_Enable_SON) ))
										{
											if(Modbus_def[index].check(Modbus_def[index].min,Modbus_def[index].max,v)) //Check OK
											{
												(*p)=v;
												writeok=1;
												if(Modbus_def[index].execute!= NULL)
												{
													Modbus_def[index].execute();
												}
											}
										}
									}
									break;
								}
								
									
							}
							else //16 bit 
							{
								if(startadr==_offset)
								{
									if(Modbus_def[index].check!= NULL)
									{
										if((!SV_ON) ||(SV_ON &&(Modbus_def[index].write_mode==MBDEF_Enable_SON) ))
										{
											if(Modbus_def[index].check(Modbus_def[index].min,Modbus_def[index].max,value)) //Check OK
											{
												MBData[startadr]=value;
												writeok=1;
												if(Modbus_def[index].execute!= NULL)
												{
													Modbus_def[index].execute();
												}
											}
										}
									}
									break;
								}
							}
							index++;
						}
						if(index>=MAX_MBDEF)// Address not in table 
						{
							
						}
					}
					for(i=0;i<8;i++)
						TXbuf[i]=RXbuf[i];
					TXlen=8;
					if(!writeok)
					{
						TXlen=5;
						TXbuf[1]=TXbuf[1]|0x80;
						TXbuf[2]=0x7;
						MB_CRC16(TXbuf,TXlen-2,&TXbuf[TXlen-2],&TXbuf[TXlen-1]);
					}
					return TXlen;
				case 0x10:// Write multiple Register
					if((RXbuf[4]!=0)|| (RXbuf[6]!=(RXbuf[5]<<1))||(RXbuf[5]>125)||(RXlen!=(RXbuf[6])+9)) // Register number >125 or packet length is not correct(8)
					{
						return 0;
					}
					startadr=(RXbuf[2]<<8)+RXbuf[3];
				  reg_num=(RXbuf[5]);
					if((startadr+reg_num)>=MB_MAX_REG) //Outbound
					{
						return 0;
					}
					for(i=0;i<RXbuf[6];i+=2)
					{
						unsigned short value16=(RXbuf[7+i]<<8)+RXbuf[8+i]; //value to write
						u32 value32;
						unsigned short addr=startadr+(i>>1);
						u32 w32addrok=((i+2)<RXbuf[6]);
						// Check if address in the parameter list
						int index=0;
						if(w32addrok)
						{
							value32=(RXbuf[7+i]<<8)+RXbuf[8+i]+(RXbuf[9+i]<<24)+(RXbuf[10+i]<<16);
						}
						
						while(index<MAX_MBDEF)
						{
							u16 _type=Modbus_def[index].type;
							u16 _offset= Modbus_def[index].offset;
							u32 *p=(u32*)&MBData[_offset];
							if(_type== MBDEF_U32 && w32addrok) //32 bit address
							{
								if(addr==_offset)
								{
									if(Modbus_def[index].check!= NULL)
									{
										if((!SV_ON) ||(SV_ON &&(Modbus_def[index].write_mode==MBDEF_Enable_SON) ))
										{
											if(Modbus_def[index].check(Modbus_def[index].min,Modbus_def[index].max,value32)) //Check OK
											{
												(*p)=value32;
												if(Modbus_def[index].execute!= NULL)
												{
													Modbus_def[index].execute();
												}
											}
										}
									}
									i=i+2;
									break;
								}
							}
							else //16 bit 
							{
								if(addr==_offset)
								{
									if(Modbus_def[index].check!= NULL)
									{
										if((!SV_ON) ||(SV_ON &&(Modbus_def[index].write_mode==MBDEF_Enable_SON) ))
										{
											if(Modbus_def[index].check(Modbus_def[index].min,Modbus_def[index].max,value16)) //Check OK
											{
												MBData[addr]=value16;
												if(Modbus_def[index].execute!= NULL)
												{
													Modbus_def[index].execute();
												}
											}
										}
									}
									break;
								}
							}
							index++;
						}
					}
					TXbuf[0]=RXbuf[0];TXbuf[1]=RXbuf[1];
					TXbuf[2]=(unsigned char)(reg_num<<1);
					TXpt=&TXbuf[3];
					TXlen=8;
					for(i=0;i<6;i++)
						TXbuf[i]=RXbuf[1];
					MB_CRC16(TXbuf,TXlen-2,&TXbuf[TXlen-2],&TXbuf[TXlen-1]);
					return TXlen;
					//break;
					
					
				default:
					break;
			}
		
		}
		else //CRC check fail
		{
			return 0;
		}
	}
	return 0;
}


