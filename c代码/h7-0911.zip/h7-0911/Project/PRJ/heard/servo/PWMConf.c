/**
  ******************************************************************************
  * @�ļ���    PWMConf.c 
  * @����      
  * @�汾      V1.1.0
  * @����      
  * @����      ����PWM����
  ******************************************************************************
  * @ע������
  *
  * ���裺TIM1��6·����PWM���
  * ����ģʽ�����ĶԳƼ���ģʽ + ����ֵ���ڱȽ�ֵʱΪ��Ч��ƽ �ߵ�ƽ
  * �ܽţ�PE8~13;  PE14:PWM4���ͬ���źŵ�CPLD
  * ������2us  
  ******************************************************************************
  */ 
#include "main.h"
#include "Globale_Variable.h"

void PWMConf(void)  //pwm����
{
  /* TIM1 Configuration */
  GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;
	TIM_BDTRInitTypeDef TIM_BDTRInitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
  /* GPIOE clocks enable */
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE);
  /* TIM1 clock enable */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);
                     
  /* GPIOE Configuration: Channel 1 and 3 as alternate function push-pull */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;  //?
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;//GPIO_PuPd_UP
  GPIO_Init(GPIOE, &GPIO_InitStructure); 
  
	/* Connect TIM pins to AF1 */
  GPIO_PinAFConfig(GPIOE, GPIO_PinSource15, GPIO_AF_TIM1);
	/* GPIOE15 Configuration: BRAKE_IN */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz; 
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
  GPIO_Init(GPIOE, &GPIO_InitStructure); 
	
  /* Connect TIM pins to AF1 */
  GPIO_PinAFConfig(GPIOE, GPIO_PinSource8, GPIO_AF_TIM1);
  GPIO_PinAFConfig(GPIOE, GPIO_PinSource9, GPIO_AF_TIM1);
  GPIO_PinAFConfig(GPIOE, GPIO_PinSource10, GPIO_AF_TIM1);
  GPIO_PinAFConfig(GPIOE, GPIO_PinSource11, GPIO_AF_TIM1); 
  GPIO_PinAFConfig(GPIOE, GPIO_PinSource12, GPIO_AF_TIM1);    
  GPIO_PinAFConfig(GPIOE, GPIO_PinSource13, GPIO_AF_TIM1);

  NVIC_InitStructure.NVIC_IRQChannel = TIM1_UP_TIM10_IRQn; //TIM1 Update Interrupt�����ж�����
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	 /* Configure two bits for preemption priority */
  //NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//�жϷ���
  NVIC_Init(&NVIC_InitStructure);

	//NVIC_InitStructure.NVIC_IRQChannel = TIM1_CC_IRQn;//TIM1 Capture Compare Interrupt ��Ϊ���������
	//NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 5;
  //NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  //NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	//NVIC_Init(&NVIC_InitStructure);

  /* Time Base configuration */
  TIM_TimeBaseStructure.TIM_Prescaler = 0;
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_CenterAligned3;
  TIM_TimeBaseStructure.TIM_Period = (int)TPeriod;
  TIM_TimeBaseStructure.TIM_ClockDivision = 0;
  TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;

  TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);
	/* Prescaler configuration */
  TIM_PrescalerConfig(TIM1, 0, TIM_PSCReloadMode_Immediate);
  /* Channel 1, 2 and 3 Configuration in PWM mode */
  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Enable;
  TIM_OCInitStructure.TIM_Pulse = (int)TPeriod/2;
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low;//v2/v3   TIM_OCPolarity_High-old v1;
  TIM_OCInitStructure.TIM_OCNPolarity = TIM_OCNPolarity_Low;// v2\v3  TIM_OCNPolarity_High-old v1;
  TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Reset;
  TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCNIdleState_Reset;

  TIM_OCInitStructure.TIM_Pulse = (int)TPeriod/2;
  TIM_OC1Init(TIM1, &TIM_OCInitStructure);
  TIM_OCInitStructure.TIM_Pulse = (int)TPeriod/2;
  TIM_OC2Init(TIM1, &TIM_OCInitStructure);
  TIM_OCInitStructure.TIM_Pulse = (int)TPeriod/2;
  TIM_OC3Init(TIM1, &TIM_OCInitStructure);	
	//TIM_OCInitStructure.TIM_Pulse = (int)(TPeriod<<2);
  //TIM_OC4Init(TIM1, &TIM_OCInitStructure);
	
	TIM_SelectOutputTrigger(TIM1, TIM_TRGOSource_Update);  //ѡ��trigger�¼�Ϊ�����¼�
  TIM_ARRPreloadConfig(TIM1, ENABLE);
  TIM_OC1PreloadConfig(TIM1, TIM_OCPreload_Enable);
  TIM_OC2PreloadConfig(TIM1, TIM_OCPreload_Enable);
  TIM_OC3PreloadConfig(TIM1, TIM_OCPreload_Enable);
	//TIM_OC4PreloadConfig(TIM1, TIM_OCPreload_Enable);
	
  /* Automatic Output enable, Break, dead time and lock configuration*/
  TIM_BDTRInitStructure.TIM_OSSRState = TIM_OSSRState_Enable;
  TIM_BDTRInitStructure.TIM_OSSIState = TIM_OSSIState_Enable;
  TIM_BDTRInitStructure.TIM_LOCKLevel = TIM_LOCKLevel_OFF;
  TIM_BDTRInitStructure.TIM_DeadTime = 0xc8;//223;3us c8:1.9us
  TIM_BDTRInitStructure.TIM_Break = TIM_Break_Enable;
  TIM_BDTRInitStructure.TIM_BreakPolarity = TIM_BreakPolarity_Low;
  TIM_BDTRInitStructure.TIM_AutomaticOutput = TIM_AutomaticOutput_Disable;

  TIM_BDTRConfig(TIM1, &TIM_BDTRInitStructure);
	
  /* TIM1 counter enable */
  TIM_Cmd(TIM1, ENABLE);
  /* Main Output Enable */
  TIM_CtrlPWMOutputs(TIM1, ENABLE);
	
	TIM_ITConfig(TIM1, TIM_IT_Update, ENABLE);
	//TIM_ITConfig(TIM1, TIM_IT_Update | TIM_IT_CC4 , ENABLE);
	
	//------------------------------------------------------------------------
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);
	
	NVIC_InitStructure.NVIC_IRQChannel = TIM5_IRQn;// ��Ϊ���������
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	  /* Time Base configuration */
  TIM_TimeBaseStructure.TIM_Prescaler = 7;
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseStructure.TIM_Period = 10500; //1ms
  TIM_TimeBaseStructure.TIM_ClockDivision = 0;
  TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM5, &TIM_TimeBaseStructure);

  TIM_Cmd(TIM5, ENABLE);
	TIM_ITConfig(TIM5, TIM_IT_Update , ENABLE);
}
	

