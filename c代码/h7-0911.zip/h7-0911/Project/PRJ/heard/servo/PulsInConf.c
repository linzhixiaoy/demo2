/**
  ******************************************************************************
  * @�ļ���    PulsInConf.c
  * @����      
  * @�汾      V1.0.0
  * @����      2017.10.1
  * @����      ������������TIM8
  ******************************************************************************
  * @ע������
  *
  *
  * 
  * 
  * 
  ******************************************************************************
  */ 
#include "main.h"
#include "Globale_Variable.h"

void PulsInConf(void) 
{	NVIC_InitTypeDef       NVIC_InitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	GPIO_InitTypeDef GPIO_InitStructure;
  TIM_ICInitTypeDef TIM_ICInitStructure;
	 /* TIM clock enable */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM8, ENABLE);
 
	/* GPIOC Clocks enable */
	RCC_AHB1PeriphClockCmd( RCC_AHB1Periph_GPIOC, ENABLE);
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);

	
	NVIC_InitStructure.NVIC_IRQChannel = TIM8_UP_TIM13_IRQn;//ADC1DMA�ж�����
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;//0
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;	
	NVIC_Init(&NVIC_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin =   GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP ;
	GPIO_Init(GPIOC, &GPIO_InitStructure);

	GPIO_PinAFConfig(GPIOC, GPIO_PinSource6, GPIO_AF_TIM8);
	GPIO_PinAFConfig(GPIOC, GPIO_PinSource7, GPIO_AF_TIM8);

	/* Time base configuration */
	TIM_TimeBaseStructure.TIM_Period = 0xFFFF;
	TIM_TimeBaseStructure.TIM_Prescaler = 0;
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	//TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM8, &TIM_TimeBaseStructure);
	/* Prescaler configuration */
//	TIM_PrescalerConfig(TIM8, 0, TIM_PSCReloadMode_Immediate);
			
	//if(SysPara[PLUSE_IN_MOD].data==0)
	//{
	//	TIM_EncoderInterfaceConfig(TIM8, TIM_EncoderMode_TI1, TIM_ICPolarity_Rising, 0);
	//}
	//else
	//{
		TIM_EncoderInterfaceConfig(TIM8, TIM_EncoderMode_TI12, TIM_ICPolarity_Rising, TIM_ICPolarity_Rising);
	//}
  TIM_ICStructInit(&TIM_ICInitStructure);
  TIM_ICInitStructure.TIM_ICFilter = 0;
  TIM_ICInit(TIM8, &TIM_ICInitStructure);
	//����ʱҪ���ô˹��ܣ���߿�����
	//TIM8->CCMR1|=(((uint16_t)SysPara[TEPCK11].data&0x000F)<<4)|(((uint16_t)SysPara[TEPCK11].data&0x000F)<<12);
	//TIM8->CCMR1|=0X5050;
  TIM_ClearFlag(TIM8, TIM_FLAG_Update);	
	TIM_ITConfig(TIM8, TIM_IT_Update, ENABLE);
	TIM_Cmd(TIM8, ENABLE);
}
//End
