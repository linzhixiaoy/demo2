#ifndef __UART1_KEYBOARD__H
#define __UART1_KEYBOARD__H

extern	void _UART1Conf(void);
extern	void KEY_Board(void);
#endif 

//End
