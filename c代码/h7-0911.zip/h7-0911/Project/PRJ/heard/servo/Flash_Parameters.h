#ifndef __FLASH_PARA_H
#define __FLASH_PARA_H
#include "LED_UI.h"
#define MAX_SECTOR 32
#define SECTOR_SIZE 1024

void check_flash_para(void);

u8 check_empty_sector(u16 sector);
u8 check_sector_crc(u16 sector);
void Write_Para(u16 sector);
void Write_Config(void);
void Read_Para(u16 sector);
#endif

