/**
  ******************************************************************************
  * @�ļ���    MB_P6.c 
  * @����     
  * @�汾      V1.0.0
  * @����     
  * @����      Modbus communication on USART6 
  ******************************************************************************
  * @ע������
  * �̶�������Ϊ 115200��8,n,1 RTU
  *  
  * 
  ******************************************************************************
  */ 

#include "main.h"
#include "MBcrc.h"
#include "MB_P6.h"
//------------
#define MBP6_UART USART6 // Port1 uart6 
#define MBP6_RX_MAX 256
#define MBP6_TX_MAX 256
unsigned char USART6RXbuf[MBP6_RX_MAX];
unsigned char USART6TXbuf[MBP6_TX_MAX];
unsigned short USART6RXlen,USART6TXlen;
int p_MBP6_UART_state,MBP6_UART_state; //0:�ȴ����յ�һ����; 1:�ȴ�IDLE 2:����ѶϢ�� 3:���ͣ�DMA�� 4:�ȴ����һ����TC

//------------

void MB_P6_Init(void) // ��ʼ��
{
  USART_InitTypeDef   USART_InitStructure; 	
  NVIC_InitTypeDef    NVIC_InitStructure;
	DMA_InitTypeDef     DMA_InitStructure;
	GPIO_InitTypeDef    GPIO_InitStructure;
  USART_ClockInitTypeDef USART_ClockInitStruct;//
	int i;

   /* DMA1 clock enable */
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2, ENABLE);
  /* Enable USART6, GPIOD, GPIOC and AFIO clocks */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART6, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC,ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD,ENABLE);
	
  /* Configure USART6 Tx (PC.10) as alternate function push-pull */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOC, &GPIO_InitStructure); 
	GPIO_PinAFConfig(GPIOC, GPIO_PinSource6, GPIO_AF_USART6); 

  /* Configure USART6 Rx (PC.11) as alternate function  */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOC, &GPIO_InitStructure); 
	GPIO_PinAFConfig(GPIOC, GPIO_PinSource7, GPIO_AF_USART6); 

  /* Configure USART6 RS485 Enable (PD.15) as general output  */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOD, &GPIO_InitStructure); 

	DMA_DeInit(DMA2_Stream1);
  /* DMA2 Stream2 (triggered by USART6 Rx event) Config */
	DMA_InitStructure.DMA_Channel = DMA_Channel_5; 
  DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)(&(USART6->DR));//
  DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)(&USART6RXbuf);
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;
  DMA_InitStructure.DMA_BufferSize = MBP6_RX_MAX;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
  DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;
  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Enable;    //     
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;//
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;//
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;//
  DMA_Init(DMA2_Stream1, &DMA_InitStructure); 
	DMA_Cmd(DMA2_Stream1, DISABLE);  //
	/* DMA2 Stream6 (triggered by USART6 Tx event) Config */
	DMA_DeInit(DMA2_Stream6);
	DMA_InitStructure.DMA_Channel = DMA_Channel_5; 
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)(&(USART6->DR));//
  DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)(&USART6TXbuf);
  DMA_InitStructure.DMA_DIR = DMA_DIR_MemoryToPeripheral;
	DMA_InitStructure.DMA_BufferSize = MBP6_TX_MAX;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
  DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;
  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Enable; //        
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;//
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;//
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;//
  DMA_Init(DMA2_Stream6, &DMA_InitStructure);
	DMA_Cmd(DMA2_Stream6, DISABLE);
	
	DMA_ITConfig(DMA2_Stream1,DMA_IT_TC,DISABLE);//RX
	DMA_ITConfig(DMA2_Stream6,DMA_IT_TC,ENABLE);//TX

	NVIC_InitStructure.NVIC_IRQChannel = DMA2_Stream6_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel = USART6_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);



  //---Configure USART6 -------------
  USART_DeInit(USART6);
	USART_InitStructure.USART_BaudRate=115200;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
  USART_Init(USART6, &USART_InitStructure);
	USART_ClockStructInit(&USART_ClockInitStruct);//
	USART_ClockInit(USART6, &USART_ClockInitStruct);//
	
  /* Enable USART1 DMA TX request */
  USART_DMACmd(USART6, USART_DMAReq_Tx, ENABLE);
  /* Enable USART1 DMA RX request */
  USART_DMACmd(USART6, USART_DMAReq_Rx, ENABLE);
	// Interrupt configuration
  USART_ITConfig(USART6,USART_IT_TC,DISABLE);   //��������ж� DISABLE
  USART_ITConfig(USART6,USART_IT_IDLE,DISABLE);   //����IDLE�ж� DISABLE
	USART_ITConfig(USART6,USART_IT_RXNE,ENABLE);

  USART_ClearFlag(USART6, USART_FLAG_RXNE);//����жϱ�ʶ

	GPIO_ResetBits(GPIOD,GPIO_Pin_15);
 /* Enable the USART6 */
  USART_Cmd(USART6, ENABLE);	
	// UART ״̬��
	MBP6_UART_state=0; 
	for(i=0;i<10000;i++)// ��ʼ����Ҫʱ�䣬Ҫ�������ܹ����TC
	{
		USART_ClearFlag(USART6, USART_FLAG_TC);//����жϱ��
	}	
}

void DMA2_Stream6_IRQHandler(void) //UART3 ��������ж�
{
  if(DMA_GetITStatus(DMA2_Stream6,DMA_IT_TCIF6)==SET) // DMA2_Stream6 �������
	{
		DMA_ClearITPendingBit(DMA2_Stream6,DMA_IT_TCIF6);
		DMA_ClearFlag(DMA2_Stream6,DMA_IT_TCIF6);
		
// 		USART6->SR=~USART_FLAG_TC;  //�巢���жϱ�־
	
		USART_ITConfig(USART6,USART_IT_TC,ENABLE);  //�򿪴��ڷ����ж�
		DMA2_Stream1->CR&=~(uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
		MBP6_UART_state=4; 
	}
}

//------------------------------------------------------

void USART6_IRQHandler(void)
{
	DMA_InitTypeDef     DMA_InitStructure;
		
	if(((USART6->CR1)&0x40)&&((USART6->SR)&USART_FLAG_TC) )//��������ж� USARTx->SR
	{
		USART6->CR1&=~0X00000040;    // �ط����ж�
		USART6->SR=~USART_FLAG_TC;   //�巢��������
		USART6->SR=~USART_FLAG_RXNE; //����ձ�־
		USART6->CR1|=0X00000020;    //�������ж�
				
		MBP6_UART_state=0; 
		//GPIO_ResetBits(GPIOD,GPIO_Pin_15);
		
		return;
	}
		
	if(((USART6->CR1)&0x20)&&((USART6->SR)&USART_FLAG_RXNE)!=0)   //���������ж�
	{
		USART6->CR1&=~0X00000020;    //�ؽ����ж�
		USART6->SR=~USART_FLAG_RXNE; //����ձ�־
		
		DMA2_Stream1->NDTR = MBP6_RX_MAX;
		DMA2_Stream1->CR|= (uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
		
		USART6->SR=~USART_FLAG_IDLE; //�����߿��б�־ 
		USART6->CR1|=0X00000010;   //�����߿����ж�
		MBP6_UART_state=1; 
			//GPIO_ResetBits(GPIOD,GPIO_Pin_15);
		return;
	}
		
	if(((USART6->CR1)&0x10)&&((USART6->SR)&USART_FLAG_IDLE)!=0)  //���߿����ж�
	{
		USART6->CR1&=~0X00000020;    //�ؽ����ж�
		USART6->SR=~USART_FLAG_RXNE; //����ձ�־
		
		USART6->CR1&=~0X00000010;    //�ؿ����ж�
		USART6->SR=~USART_FLAG_IDLE; //����б�־
		do
		{
			USART6->SR;
			USART6->DR;
		}while(0);
		USART6RXlen=MBP6_RX_MAX-DMA2_Stream1->NDTR;
		
		DMA2_Stream1->CR&=~(uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
		DMA2_Stream1->NDTR = MBP6_RX_MAX;
		//DMA1->LIFCR = DMA_Stream1_IT_MASK;
		DMA_DeInit(DMA2_Stream1);
		/* DMA1 Stream1 (triggered by USART6 Rx event) Config */
		DMA_InitStructure.DMA_Channel = DMA_Channel_5; 
		DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)(&(USART6->DR));//
		DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)(&USART6RXbuf);
		DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;
		DMA_InitStructure.DMA_BufferSize = MBP6_RX_MAX;
		DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
		DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
		DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
		DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
		DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
		DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;
		DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;    //     
		DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;//
		DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;//
		DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;//
		DMA_Init(DMA2_Stream1, &DMA_InitStructure); 
		DMA_Cmd(DMA2_Stream1, DISABLE);  //

		
		//	GPIO_ResetBits(GPIOD,GPIO_Pin_15);
		MBP6_UART_state=2; 
		
		return;
	}
	
	if(((USART6->SR)&USART_FLAG_ORE)!=0)//���Ǵ����ж�
	{
		USART6->CR1 &= (uint16_t)~((uint16_t)USART_CR1_UE);  //��USART1
		USART6->CR1 |= USART_CR1_UE;										//��USART1

		USART6->SR=~USART_IT_ORE;  //�帲�Ǵ����־
		
		DMA2_Stream1->CR&=~(uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
		DMA2_Stream1->NDTR = MBP6_RX_MAX;
		
		USART6->SR=~USART_FLAG_RXNE; //����ձ�־
		USART6->CR1|=0X00000020;    //�������ж�
		DMA2_Stream1->CR|= (uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
		MBP6_UART_state=0; 	
		//GPIO_ResetBits(GPIOD,GPIO_Pin_15);
		return;
	}
	
	do
	{
		USART6->SR;
		USART6->DR;
	}while(0);
	
	// �����жϣ�����USART6

	USART_Cmd(USART6, DISABLE);
		
	DMA2_Stream1->CR&=~(uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
	DMA2_Stream1->NDTR = MBP6_RX_MAX;
	
	DMA_Cmd(DMA2_Stream1, DISABLE);//��������
	
	USART6->SR=0;
	USART6->SR=~USART_FLAG_RXNE; //����ձ�־
	
	DMA2_Stream1->CR|= (uint32_t)DMA_SxCR_EN; //��DMA���ݴ���
		
	MBP6_UART_state=0; 	
	//GPIO_ResetBits(GPIOD,GPIO_Pin_15);	
	USART6->CR1|=0X00000020;    //�������ж�
	USART_Cmd(USART6, ENABLE);

}
void MB_P6_1ms_proc(void) //��ֹ��������
{
	DMA_InitTypeDef     DMA_InitStructure;

	if(p_MBP6_UART_state==MBP6_UART_state) //״̬����
	{
		switch(MBP6_UART_state)
		{
			case 0: //�ȴ���һ����Ԫ
				if(!(USART6->SR&USART_FLAG_RXNE)) //�н��������ˣ�����Ƿ��ж�û��
				{
								
				}
				break;
			case 1: 
				break;
		}
	}
	if(MBP6_UART_state==2) // Data process
	{
		USART6TXlen=RTU_Data_Proc(USART6RXbuf,USART6TXbuf,USART6RXlen,2);
		if(USART6TXlen>0)
		{
			GPIO_SetBits(GPIOD,GPIO_Pin_15);
			DMA_DeInit(DMA2_Stream6);
			DMA_InitStructure.DMA_Channel = DMA_Channel_5; 
			DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)(&(USART6->DR));//
			DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)(&USART6TXbuf);
			DMA_InitStructure.DMA_DIR = DMA_DIR_MemoryToPeripheral;
			DMA_InitStructure.DMA_BufferSize = USART6TXlen;
			DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
			DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
			DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
			DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
			DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
			DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;
			DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Enable; //        
			DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;//
			DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;//
			DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;//
			DMA_Init(DMA2_Stream6, &DMA_InitStructure);
			DMA_Cmd(DMA2_Stream6, ENABLE);
			USART6->SR=~USART_FLAG_TC;   //�巢��������
			USART6->CR1|=0X00000040;    // �������ж�
			
			MBP6_UART_state=3;
		}
		else
		{			
			USART6->SR=~USART_FLAG_RXNE; //����ձ�־
			USART6->CR1|=0X00000020;    //�������ж�
			//GPIO_ResetBits(GPIOD,GPIO_Pin_15);
			
			MBP6_UART_state=0; 			
		}		
	}
	p_MBP6_UART_state=MBP6_UART_state;	
	
	if(MBP6_UART_state == 0)
		GPIO_ResetBits(GPIOD,GPIO_Pin_15);
}
//------------------------------------------------------
