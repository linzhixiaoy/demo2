#ifndef __IWDTCONF_H
#define __IWDTCONF_H

void InitIWathdog(void);

#endif 

//End
