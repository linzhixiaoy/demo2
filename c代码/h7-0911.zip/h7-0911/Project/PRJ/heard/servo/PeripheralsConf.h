#ifndef __PERIHERALSCONF_H
#define __PERIHERALSCONF_H

#include "PWMConf.h"
#include "DBGMCUConf.h"
#include "DACConf.h"
#include "MBcrc.h"
#include "MB_P3.h"
#include "MB_P4.h"
#include "MB_P6.h"
#include "ENC_P1.h"

#include "GPIOConf.h"
#include "IWDTConf.h"
#include "UART1_Keyboard.h"
#include "TM1637.h"
#include "Hso.h"
void PeripheralsConf(void);

#endif 

//End
